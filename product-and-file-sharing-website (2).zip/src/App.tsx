import { useEffect, useMemo, useState, type FormEvent, type ReactNode } from "react";

type Role = "owner" | "admin" | "member";
type Accent = "sage" | "copper" | "blue";
type View = "site" | "admin";
type AdminTab = "overview" | "files" | "announcements" | "sections" | "support" | "users" | "settings";

type SocialLink = { id: string; label: string; url: string };
type Section = { id: string; label: string };
type SiteSettings = {
  siteName: string;
  slogan: string;
  contactEmail: string;
  ownerEmail: string;
  channelUrl: string;
  bannerAssetId?: string;
  accent: Accent;
  socials: SocialLink[];
};
type FileRecord = {
  id: string;
  title: string;
  fileName: string;
  description: string;
  sectionId: string;
  assetId: string;
  mime: string;
  size: number;
  createdAt: string;
  downloads: number;
};
type DownloadRecord = { fileId: string; at: string };
type UserRecord = {
  id: string;
  name: string;
  email: string;
  role: Role;
  passwordSalt: string;
  passwordHash: string;
  downloads: DownloadRecord[];
  createdAt: string;
};
type PostRecord = { id: string; title: string; body: string; createdAt: string };
type TicketReply = { body: string; by: string; at: string };
type SupportTicket = {
  id: string;
  name: string;
  email: string;
  userId?: string;
  message: string;
  createdAt: string;
  status: "new" | "answered";
  replies: TicketReply[];
};
type SiteData = {
  settings: SiteSettings;
  sections: Section[];
  files: FileRecord[];
  posts: PostRecord[];
  users: UserRecord[];
  tickets: SupportTicket[];
};
type SupportDraft = { name: string; email: string; message: string; userId?: string };
type AuthResult = { ok: boolean; message: string; user?: UserRecord };

const DATA_KEY = "atelier-site-data-v1";
const SESSION_KEY = "atelier-site-session-v1";
const ASSET_DB = "atelier-site-assets-v1";
const DEFAULT_OWNER_PASSWORD = "Studio!1405#";

const DEFAULT_SETTINGS: SiteSettings = {
  siteName: "استودیو الیاس",
  slogan: "فایل‌های خوب، شروع پروژه‌های بهترند.",
  contactEmail: "eliasbadiyab@gmail.com",
  ownerEmail: "eliasbadiyab@gmail.com",
  channelUrl: "",
  accent: "sage",
  socials: [],
};

const DEFAULT_SECTIONS: Section[] = [
  { id: "templates", label: "قالب‌ها" },
  { id: "resources", label: "منابع آموزشی" },
  { id: "useful", label: "فایل‌های کاربردی" },
];

const EMPTY_DATA: SiteData = {
  settings: DEFAULT_SETTINGS,
  sections: DEFAULT_SECTIONS,
  files: [],
  posts: [],
  users: [],
  tickets: [],
};

type IconName =
  | "spark"
  | "home"
  | "folder"
  | "download"
  | "search"
  | "message"
  | "user"
  | "lock"
  | "arrow"
  | "upload"
  | "layout"
  | "megaphone"
  | "layers"
  | "users"
  | "settings"
  | "eye"
  | "logout"
  | "plus"
  | "file"
  | "trash"
  | "link"
  | "mail"
  | "send"
  | "check"
  | "clock"
  | "close"
  | "image"
  | "shield"
  | "menu"
  | "external"
  | "key"
  | "chevron"
  | "youtube"
  | "book"
  | "alert";

const ICONS: Record<IconName, ReactNode> = {
  spark: <><path d="m12 3 1.7 5.3L19 10l-5.3 1.7L12 17l-1.7-5.3L5 10l5.3-1.7L12 3Z" /><path d="m19 14 .9 2.1L22 17l-2.1.9L19 20l-.9-2.1L16 17l2.1-.9L19 14Z" /></>,
  home: <><path d="m3 10 9-7 9 7" /><path d="M5 9v11h14V9M9 20v-6h6v6" /></>,
  folder: <><path d="M3 7.5A2.5 2.5 0 0 1 5.5 5h4l2 2h7A2.5 2.5 0 0 1 21 9.5v8a2.5 2.5 0 0 1-2.5 2.5h-13A2.5 2.5 0 0 1 3 17.5v-10Z" /></>,
  download: <><path d="M12 3v12m0 0 4-4m-4 4-4-4" /><path d="M5 16v4h14v-4" /></>,
  search: <><circle cx="10.8" cy="10.8" r="6.3" /><path d="m16 16 4.5 4.5" /></>,
  message: <><path d="M20 11.5a7.5 7.5 0 0 1-7.5 7.5H5l1.4-3.2A7.5 7.5 0 1 1 20 11.5Z" /><path d="M8.5 11.5h.01m3.5 0h.01m3.5 0h.01" /></>,
  user: <><circle cx="12" cy="8" r="3.5" /><path d="M5 20c.6-3.3 3-5 7-5s6.4 1.7 7 5" /></>,
  lock: <><rect x="4" y="10" width="16" height="11" rx="2" /><path d="M8 10V7a4 4 0 0 1 8 0v3m-4 4v3" /></>,
  arrow: <><path d="M7 17 17 7M7 7h10v10" /></>,
  upload: <><path d="M12 16V4m0 0L8 8m4-4 4 4" /><path d="M5 14v5h14v-5" /></>,
  layout: <><rect x="3" y="4" width="18" height="16" rx="2" /><path d="M9 4v16M9 9h12" /></>,
  megaphone: <><path d="m4 13 12 5V6L4 11v2Zm0 0 2 6h4l-2-4" /><path d="M16 9h2a3 3 0 0 1 0 6h-2" /></>,
  layers: <><path d="m12 3 9 5-9 5-9-5 9-5Z" /><path d="m3 12 9 5 9-5M3 16l9 5 9-5" /></>,
  users: <><circle cx="9" cy="8" r="3" /><path d="M3.5 20c.4-3 2.2-4.5 5.5-4.5s5.1 1.5 5.5 4.5" /><path d="M16 5.3a3 3 0 0 1 0 5.4m2.5 3c1.4.8 2.1 2 2.3 3.8" /></>,
  settings: <><circle cx="12" cy="12" r="3" /><path d="m19.4 15 .1.1 1.1 1.8-1.8 3.1-2.1-.5a8 8 0 0 1-1.8 1l-.5 2.1h-3.6l-.5-2.1a8 8 0 0 1-1.8-1l-2.1.5-1.8-3.1 1.1-1.8a8 8 0 0 1 0-2l-1.1-1.8 1.8-3.1 2.1.5a8 8 0 0 1 1.8-1l.5-2.1h3.6l.5 2.1a8 8 0 0 1 1.8 1l2.1-.5 1.8 3.1-1.1 1.8a8 8 0 0 1 0 2Z" transform="translate(-1 -2) scale(1.08)" /></>,
  eye: <><path d="M2.5 12s3.4-6 9.5-6 9.5 6 9.5 6-3.4 6-9.5 6-9.5-6-9.5-6Z" /><circle cx="12" cy="12" r="2.5" /></>,
  logout: <><path d="M10 17 15 12l-5-5m5 5H3" /><path d="M12 3h6a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-6" /></>,
  plus: <><path d="M12 5v14m-7-7h14" /></>,
  file: <><path d="M6 3h8l5 5v13H6a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2Z" /><path d="M14 3v6h5M8 13h8m-8 4h8" /></>,
  trash: <><path d="M4 7h16m-10 4v6m4-6v6M6 7l1 14h10l1-14M9 7V4h6v3" /></>,
  link: <><path d="M10 13a5 5 0 0 0 7.1 0l2-2A5 5 0 0 0 12 3.9l-1.1 1.1" /><path d="M14 11a5 5 0 0 0-7.1 0l-2 2A5 5 0 0 0 12 20.1l1.1-1.1" /></>,
  mail: <><rect x="3" y="5" width="18" height="14" rx="2" /><path d="m4 7 8 6 8-6" /></>,
  send: <><path d="m22 2-7 20-4-9-9-4 20-7Z" /><path d="M22 2 11 13" /></>,
  check: <><path d="m5 12 4 4L19 6" /></>,
  clock: <><circle cx="12" cy="12" r="9" /><path d="M12 7v5l3 2" /></>,
  close: <><path d="m6 6 12 12M18 6 6 18" /></>,
  image: <><rect x="3" y="4" width="18" height="16" rx="2" /><circle cx="8.5" cy="9" r="1.5" /><path d="m21 15-5-5L5 20" /></>,
  shield: <><path d="M12 22s8-4 8-11V5l-8-3-8 3v6c0 7 8 11 8 11Z" /><path d="m9 12 2 2 4-4" /></>,
  menu: <><path d="M4 7h16M4 12h16M4 17h16" /></>,
  external: <><path d="M14 4h6v6m0-6-9 9" /><path d="M18 13v6a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1h6" /></>,
  key: <><circle cx="8" cy="15" r="5" /><path d="m11.5 11.5 8-8L22 6l-2 2 1.5 1.5-2.5 2.5-1.5-1.5-2 2" /></>,
  chevron: <><path d="m8 10 4 4 4-4" /></>,
  youtube: <><rect x="3" y="5" width="18" height="14" rx="4" /><path d="m10 9 5 3-5 3V9Z" /></>,
  book: <><path d="M4 5.5A2.5 2.5 0 0 1 6.5 3H20v17H6.5A2.5 2.5 0 0 1 4 17.5v-12Z" /><path d="M4 16.5A2.5 2.5 0 0 1 6.5 14H20M8 7h7" /></>,
  alert: <><path d="M12 3 2.8 20h18.4L12 3Z" /><path d="M12 9v4m0 3h.01" /></>,
};

function Icon({ name, size = 18 }: { name: IconName; size?: number }) {
  return (
    <svg
      aria-hidden="true"
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.7"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      {ICONS[name]}
    </svg>
  );
}

function makeId(prefix: string) {
  const random = globalThis.crypto?.randomUUID?.() ?? `${Date.now()}-${Math.random().toString(36).slice(2)}`;
  return `${prefix}-${random}`;
}

function formatBytes(bytes: number) {
  if (bytes < 1024) return `${new Intl.NumberFormat("fa-IR").format(bytes)} بایت`;
  const units = ["کیلوبایت", "مگابایت", "گیگابایت"];
  let size = bytes / 1024;
  let index = 0;
  while (size >= 1024 && index < units.length - 1) {
    size /= 1024;
    index += 1;
  }
  return `${new Intl.NumberFormat("fa-IR", { maximumFractionDigits: 1 }).format(size)} ${units[index]}`;
}

function formatDate(value: string) {
  return new Intl.DateTimeFormat("fa-IR", { dateStyle: "medium" }).format(new Date(value));
}

function roleLabel(role: Role) {
  if (role === "owner") return "مالک";
  if (role === "admin") return "مدیر";
  return "عضو";
}

function normalizeUrl(value: string) {
  const trimmed = value.trim();
  if (!trimmed) return "";
  return /^https?:\/\//i.test(trimmed) ? trimmed : `https://${trimmed}`;
}

function openAssetDatabase(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (!window.indexedDB) {
      reject(new Error("ذخیره‌سازی فایل در این مرورگر در دسترس نیست."));
      return;
    }
    const request = window.indexedDB.open(ASSET_DB, 1);
    request.onupgradeneeded = () => {
      const database = request.result;
      if (!database.objectStoreNames.contains("assets")) {
        database.createObjectStore("assets", { keyPath: "id" });
      }
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error ?? new Error("باز کردن فضای فایل‌ها ناموفق بود."));
  });
}

type StoredAsset = { id: string; blob: Blob; fileName: string; mime: string };

async function saveAsset(blob: Blob, fileName: string) {
  const database = await openAssetDatabase();
  const asset: StoredAsset = {
    id: makeId("asset"),
    blob,
    fileName,
    mime: blob.type || "application/octet-stream",
  };
  return new Promise<string>((resolve, reject) => {
    const transaction = database.transaction("assets", "readwrite");
    transaction.objectStore("assets").put(asset);
    transaction.oncomplete = () => {
      database.close();
      resolve(asset.id);
    };
    transaction.onerror = () => {
      database.close();
      reject(transaction.error ?? new Error("ذخیره فایل انجام نشد."));
    };
    transaction.onabort = () => {
      database.close();
      reject(transaction.error ?? new Error("ذخیره فایل لغو شد."));
    };
  });
}

async function readAsset(id: string): Promise<StoredAsset | null> {
  const database = await openAssetDatabase();
  return new Promise((resolve, reject) => {
    const transaction = database.transaction("assets", "readonly");
    const request = transaction.objectStore("assets").get(id);
    request.onsuccess = () => resolve((request.result as StoredAsset | undefined) ?? null);
    request.onerror = () => reject(request.error ?? new Error("خواندن فایل ناموفق بود."));
    transaction.oncomplete = () => database.close();
    transaction.onerror = () => {
      database.close();
      reject(transaction.error ?? new Error("خواندن فایل ناموفق بود."));
    };
  });
}

async function removeAsset(id: string) {
  const database = await openAssetDatabase();
  return new Promise<void>((resolve, reject) => {
    const transaction = database.transaction("assets", "readwrite");
    transaction.objectStore("assets").delete(id);
    transaction.oncomplete = () => {
      database.close();
      resolve();
    };
    transaction.onerror = () => {
      database.close();
      reject(transaction.error ?? new Error("حذف فایل انجام نشد."));
    };
  });
}

async function derivePassword(password: string, saltValue?: string) {
  if (!window.crypto?.subtle) throw new Error("برای ورود امن، از مرورگر به‌روز استفاده کنید.");
  const salt = saltValue ?? makeId("salt");
  const material = await window.crypto.subtle.importKey(
    "raw",
    new TextEncoder().encode(password),
    "PBKDF2",
    false,
    ["deriveBits"],
  );
  const bits = await window.crypto.subtle.deriveBits(
    { name: "PBKDF2", salt: new TextEncoder().encode(salt), iterations: 120_000, hash: "SHA-256" },
    material,
    256,
  );
  const hash = Array.from(new Uint8Array(bits), (byte) => byte.toString(16).padStart(2, "0")).join("");
  return { salt, hash };
}

function useAssetUrl(assetId?: string) {
  const [url, setUrl] = useState("");
  useEffect(() => {
    let alive = true;
    let objectUrl = "";
    setUrl("");
    if (assetId) {
      readAsset(assetId)
        .then((asset) => {
          if (alive && asset) {
            objectUrl = URL.createObjectURL(asset.blob);
            setUrl(objectUrl);
          }
        })
        .catch(() => undefined);
    }
    return () => {
      alive = false;
      if (objectUrl) URL.revokeObjectURL(objectUrl);
    };
  }, [assetId]);
  return url;
}

function Brand({ name, inverse = false }: { name: string; inverse?: boolean }) {
  return (
    <span className={`brand-lockup${inverse ? " brand-lockup-inverse" : ""}`}>
      <span className="brand-symbol" aria-hidden="true">ا</span>
      <span className="brand-name">{name}</span>
    </span>
  );
}

function FileMark({ file }: { file: FileRecord }) {
  if (file.mime.startsWith("image/")) {
    return <AssetImage assetId={file.assetId} alt={file.title} className="file-photo" />;
  }
  return (
    <span className="file-mark">
      <Icon name={file.mime.includes("pdf") ? "book" : "file"} size={22} />
    </span>
  );
}

function AssetImage({ assetId, alt, className }: { assetId?: string; alt: string; className: string }) {
  const url = useAssetUrl(assetId);
  if (!url) return <span className={`${className} image-placeholder`} aria-hidden="true"><Icon name="image" size={21} /></span>;
  return <img className={className} src={url} alt={alt} />;
}

interface PublicSiteProps {
  data: SiteData;
  user: UserRecord | null;
  selectedSection: string;
  onSelectSection: (id: string) => void;
  onOpenAccount: () => void;
  onOpenSupport: () => void;
  onOpenAdmin: () => void;
  onDownload: (file: FileRecord) => void;
}

function PublicSite({
  data,
  user,
  selectedSection,
  onSelectSection,
  onOpenAccount,
  onOpenSupport,
  onOpenAdmin,
  onDownload,
}: PublicSiteProps) {
  const [search, setSearch] = useState("");
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const bannerUrl = useAssetUrl(data.settings.bannerAssetId);
  const filteredFiles = useMemo(() => {
    const normalizedSearch = search.trim().toLocaleLowerCase();
    return data.files.filter((file) => {
      const sectionMatches = selectedSection === "all" || file.sectionId === selectedSection;
      const textMatches = !normalizedSearch || `${file.title} ${file.description} ${file.fileName}`.toLocaleLowerCase().includes(normalizedSearch);
      return sectionMatches && textMatches;
    });
  }, [data.files, search, selectedSection]);

  const scrollTo = (id: string) => {
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth", block: "start" });
    setMobileMenuOpen(false);
  };

  const heroImage = bannerUrl || "/images/creative-studio.jpg";

  return (
    <div className="public-site">
      <section
        className="hero"
        style={{ backgroundImage: `linear-gradient(90deg, rgba(19, 28, 24, .28), rgba(19, 28, 24, .55) 54%, rgba(19, 28, 24, .58)), url("${heroImage}")` }}
      >
        <header className="site-header">
          <a className="brand-anchor" href="#top" aria-label={data.settings.siteName}>
            <Brand name={data.settings.siteName} inverse />
          </a>
          <button
            className="mobile-menu-button"
            onClick={() => setMobileMenuOpen((open) => !open)}
            aria-label={mobileMenuOpen ? "بستن فهرست" : "باز کردن فهرست"}
            aria-expanded={mobileMenuOpen}
          >
            <Icon name={mobileMenuOpen ? "close" : "menu"} />
          </button>
          <nav className={`site-nav${mobileMenuOpen ? " site-nav-open" : ""}`} aria-label="فهرست اصلی">
            <button className="site-nav-link" onClick={() => scrollTo("top")}><Icon name="home" size={16} /> خانه</button>
            <button className="site-nav-link" onClick={() => scrollTo("files")}><Icon name="folder" size={16} /> فایل‌ها</button>
            {data.posts.length > 0 && <button className="site-nav-link" onClick={() => scrollTo("updates")}><Icon name="megaphone" size={16} /> خبرها</button>}
            <button className="site-nav-link" onClick={onOpenSupport}><Icon name="message" size={16} /> پشتیبانی</button>
          </nav>
          <div className="header-actions">
            <button className="header-account" onClick={onOpenAccount}>
              <Icon name="user" size={17} />
              <span>{user ? "حساب من" : "ورود / عضویت"}</span>
            </button>
            <button className="header-owner" onClick={onOpenAdmin}>
              <Icon name="layout" size={17} />
              <span>پنل سازنده</span>
              <Icon name="arrow" size={15} />
            </button>
          </div>
        </header>

        <div className="hero-content" id="top">
          <p className="hero-eyebrow"><span className="eyebrow-mark" /> فضای دیجیتال الیاس</p>
          <h1>{data.settings.siteName}</h1>
          <p className="hero-slogan">{data.settings.slogan}</p>
          <p className="hero-description">جای فایل‌ها، منابع و خبرهای تازه؛ همه‌چیز را یک‌جا و مرتب پیدا کن.</p>
          <div className="hero-actions">
            <button className="button button-primary" onClick={() => scrollTo("files")}>
              مرور فایل‌ها <Icon name="arrow" size={17} />
            </button>
            <button className="button button-quiet" onClick={onOpenSupport}>
              <Icon name="message" size={17} /> پیام به ما
            </button>
          </div>
        </div>
        <div className="hero-bottom" aria-hidden="true">
          <span>فایل‌های منتخب</span><span className="hero-line" /><span>برای استفاده آزاد</span>
        </div>
      </section>

      <main>
        {data.posts.length > 0 && (
          <section className="updates-section content-width" id="updates">
            <div className="section-kicker"><Icon name="megaphone" size={16} /> از استودیو</div>
            <div className="updates-heading">
              <h2>تازه چه خبر؟</h2>
              <p>پیام‌ها و خبرهای تازه را همین‌جا دنبال کن.</p>
            </div>
            <div className="updates-list">
              {data.posts.slice(0, 3).map((post) => (
                <article className="update-row" key={post.id}>
                  <time>{formatDate(post.createdAt)}</time>
                  <div><h3>{post.title}</h3><p>{post.body}</p></div>
                  <Icon name="arrow" size={18} />
                </article>
              ))}
            </div>
          </section>
        )}

        <section className="files-section content-width" id="files">
          <div className="section-heading-row">
            <div>
              <div className="section-kicker"><span className="eyebrow-mark" /> کتابخانه‌ی استودیو</div>
              <h2>چیزی برای پروژه‌ی بعدی‌ات</h2>
              <p className="section-intro">فایل‌ها را بگرد، دسته‌بندی کن و مستقیم دریافت کن.</p>
            </div>
            <label className="search-box">
              <Icon name="search" size={19} />
              <input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="جست‌وجو در فایل‌ها" aria-label="جست‌وجو در فایل‌ها" />
              {search && <button type="button" onClick={() => setSearch("")} aria-label="پاک کردن جست‌وجو"><Icon name="close" size={15} /></button>}
            </label>
          </div>

          <div className="filter-tabs" aria-label="دسته‌بندی فایل‌ها">
            <button className={selectedSection === "all" ? "filter-tab active" : "filter-tab"} onClick={() => onSelectSection("all")}>همه فایل‌ها</button>
            {data.sections.map((section) => (
              <button
                className={selectedSection === section.id ? "filter-tab active" : "filter-tab"}
                key={section.id}
                onClick={() => onSelectSection(section.id)}
              >
                {section.label}
              </button>
            ))}
          </div>

          <div className="public-file-list">
            {filteredFiles.length > 0 ? filteredFiles.map((file) => (
              <article className="public-file-row" key={file.id}>
                <FileMark file={file} />
                <div className="public-file-copy">
                  <h3>{file.title}</h3>
                  <p>{file.description || file.fileName}</p>
                </div>
                <span className="file-meta">{formatBytes(file.size)}</span>
                <button className="download-button" onClick={() => onDownload(file)}>
                  دریافت فایل <Icon name="download" size={17} />
                </button>
              </article>
            )) : (
              <div className="empty-files">
                <span className="empty-mark"><Icon name="folder" size={22} /></span>
                <div>
                  <h3>{search ? "فایلی با این عبارت پیدا نشد." : "هنوز فایلی در این بخش منتشر نشده."}</h3>
                  <p>{search ? "عبارت دیگری را امتحان کن یا جست‌وجو را پاک کن." : "به‌زودی فایل‌های تازه اینجا قرار می‌گیرند."}</p>
                </div>
                {search && <button className="text-button" onClick={() => setSearch("")}>پاک کردن جست‌وجو</button>}
              </div>
            )}
          </div>
          <div className="file-list-footnote"><Icon name="shield" size={15} /> فایل‌ها پیش از دریافت در مرورگر شما ذخیره نمی‌شوند.</div>
        </section>

        <section className="contact-band">
          <div className="content-width contact-band-inner">
            <div>
              <div className="section-kicker section-kicker-light"><span className="eyebrow-mark" /> همراه استودیو</div>
              <h2>سؤالی داری یا دنبال فایل خاصی هستی؟</h2>
              <p>پیامت را بفرست؛ از داخل همین سایت پاسخ می‌دهیم.</p>
            </div>
            <button className="button button-light" onClick={onOpenSupport}>گفت‌وگو با پشتیبانی <Icon name="arrow" size={17} /></button>
          </div>
        </section>
      </main>

      <footer className="site-footer">
        <div className="content-width footer-main">
          <div className="footer-brand">
            <Brand name={data.settings.siteName} />
            <p>{data.settings.slogan}</p>
          </div>
          <div className="footer-contact">
            <span className="footer-label">راه‌های ارتباطی</span>
            <a href={`mailto:${data.settings.contactEmail}`}><Icon name="mail" size={16} /> {data.settings.contactEmail}</a>
            {data.settings.channelUrl && <a href={normalizeUrl(data.settings.channelUrl)} target="_blank" rel="noreferrer"><Icon name="youtube" size={16} /> کانال ویدیویی <Icon name="external" size={13} /></a>}
          </div>
          {data.settings.socials.length > 0 && (
            <div className="footer-socials">
              <span className="footer-label">شبکه‌های اجتماعی</span>
              {data.settings.socials.map((social) => <a key={social.id} href={normalizeUrl(social.url)} target="_blank" rel="noreferrer">{social.label}<Icon name="external" size={13} /></a>)}
            </div>
          )}
        </div>
        <div className="content-width footer-bottom"><span>ساخته‌شده با دقت، برای کارهای خلاقانه.</span><button onClick={onOpenAdmin}>ورود سازنده <Icon name="arrow" size={14} /></button></div>
      </footer>
    </div>
  );
}

type AdminPanelProps = {
  data: SiteData;
  user: UserRecord;
  onViewSite: () => void;
  onLogout: () => void;
  onCreateFile: (file: File, title: string, description: string, sectionId: string) => Promise<boolean>;
  onDeleteFile: (file: FileRecord) => void;
  onCreatePost: (title: string, body: string) => void;
  onDeletePost: (post: PostRecord) => void;
  onCreateSection: (name: string) => boolean;
  onDeleteSection: (section: Section) => void;
  onReply: (ticketId: string, body: string) => void;
  onSetRole: (userId: string, role: Role) => void;
  onSaveSettings: (settings: SiteSettings) => void;
  onUploadBanner: (file: File) => Promise<boolean>;
  onChangePassword: (current: string, next: string) => Promise<boolean>;
};

const ADMIN_TABS: { id: AdminTab; label: string; icon: IconName }[] = [
  { id: "overview", label: "نمای کلی", icon: "layout" },
  { id: "files", label: "مدیریت فایل‌ها", icon: "folder" },
  { id: "announcements", label: "پیام‌های سایت", icon: "megaphone" },
  { id: "sections", label: "بخش‌های سایت", icon: "layers" },
  { id: "support", label: "پشتیبانی", icon: "message" },
  { id: "users", label: "کاربران و مدیرها", icon: "users" },
  { id: "settings", label: "ظاهر و تنظیمات", icon: "settings" },
];

function AdminPanel({
  data,
  user,
  onViewSite,
  onLogout,
  onCreateFile,
  onDeleteFile,
  onCreatePost,
  onDeletePost,
  onCreateSection,
  onDeleteSection,
  onReply,
  onSetRole,
  onSaveSettings,
  onUploadBanner,
  onChangePassword,
}: AdminPanelProps) {
  const [tab, setTab] = useState<AdminTab>("overview");
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [fileTitle, setFileTitle] = useState("");
  const [fileDescription, setFileDescription] = useState("");
  const [fileSectionId, setFileSectionId] = useState(data.sections[0]?.id ?? "");
  const [pendingFile, setPendingFile] = useState<File | null>(null);
  const [fileQuery, setFileQuery] = useState("");
  const [postTitle, setPostTitle] = useState("");
  const [postBody, setPostBody] = useState("");
  const [sectionName, setSectionName] = useState("");
  const [replyDrafts, setReplyDrafts] = useState<Record<string, string>>({});
  const [settingsDraft, setSettingsDraft] = useState<SiteSettings>(data.settings);
  const [socialLabel, setSocialLabel] = useState("");
  const [socialUrl, setSocialUrl] = useState("");
  const [currentPassword, setCurrentPassword] = useState("");
  const [nextPassword, setNextPassword] = useState("");
  const [securityMessage, setSecurityMessage] = useState("");
  const [bannerMessage, setBannerMessage] = useState("");
  const bannerPreviewUrl = useAssetUrl(data.settings.bannerAssetId);

  useEffect(() => setSettingsDraft(data.settings), [data.settings]);
  useEffect(() => {
    if (data.sections.length && !data.sections.some((section) => section.id === fileSectionId)) {
      setFileSectionId(data.sections[0].id);
    }
  }, [data.sections, fileSectionId]);

  const activeTab = ADMIN_TABS.find((item) => item.id === tab) ?? ADMIN_TABS[0];
  const filteredAdminFiles = useMemo(() => {
    const value = fileQuery.trim().toLocaleLowerCase();
    return data.files.filter((file) => !value || `${file.title} ${file.fileName}`.toLocaleLowerCase().includes(value));
  }, [data.files, fileQuery]);

  const submitFile = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!pendingFile || !fileTitle.trim()) return;
    const form = event.currentTarget;
    const saved = await onCreateFile(pendingFile, fileTitle.trim(), fileDescription.trim(), fileSectionId);
    if (saved) {
      form.reset();
      setPendingFile(null);
      setFileTitle("");
      setFileDescription("");
    }
  };

  const submitPost = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!postTitle.trim() || !postBody.trim()) return;
    onCreatePost(postTitle.trim(), postBody.trim());
    setPostTitle("");
    setPostBody("");
  };

  const submitSection = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (onCreateSection(sectionName)) setSectionName("");
  };

  const saveSettings = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    onSaveSettings({
      ...settingsDraft,
      siteName: settingsDraft.siteName.trim() || "استودیو الیاس",
      ownerEmail: user.role === "owner" ? settingsDraft.ownerEmail.trim().toLocaleLowerCase() : data.settings.ownerEmail,
      contactEmail: settingsDraft.contactEmail.trim(),
      channelUrl: settingsDraft.channelUrl.trim(),
    });
  };

  const addSocial = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!socialLabel.trim() || !socialUrl.trim()) return;
    setSettingsDraft((draft) => ({
      ...draft,
      socials: [...draft.socials, { id: makeId("social"), label: socialLabel.trim(), url: socialUrl.trim() }],
    }));
    setSocialLabel("");
    setSocialUrl("");
  };

  const submitPassword = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setSecurityMessage("");
    const saved = await onChangePassword(currentPassword, nextPassword);
    setSecurityMessage(saved ? "رمز عبور با موفقیت تغییر کرد." : "رمز فعلی درست نیست یا رمز تازه معتبر نیست.");
    if (saved) {
      setCurrentPassword("");
      setNextPassword("");
    }
  };

  const changeTab = (nextTab: AdminTab) => {
    setTab(nextTab);
    setMobileMenuOpen(false);
  };

  return (
    <div className="admin-app">
      <aside className={`admin-sidebar${mobileMenuOpen ? " admin-sidebar-open" : ""}`}>
        <div className="admin-brand"><Brand name={data.settings.siteName} /><span className="admin-brand-caption">فضای سازنده</span></div>
        <div className="admin-nav-label">مدیریت سایت</div>
        <nav className="admin-nav" aria-label="بخش‌های پنل سازنده">
          {ADMIN_TABS.map((item) => (
            <button key={item.id} onClick={() => changeTab(item.id)} className={`admin-nav-item${tab === item.id ? " active" : ""}`}>
              <Icon name={item.icon} size={18} /><span>{item.label}</span>
              {item.id === "support" && data.tickets.filter((ticket) => ticket.status === "new").length > 0 && <span className="nav-count">{data.tickets.filter((ticket) => ticket.status === "new").length}</span>}
            </button>
          ))}
        </nav>
        <div className="sidebar-bottom">
          <div className="sidebar-user"><span className="avatar-mark">{user.name.slice(0, 1)}</span><span><strong>{user.name}</strong><small>{roleLabel(user.role)}</small></span></div>
          <button className="sidebar-logout" onClick={onLogout}><Icon name="logout" size={16} /> خروج از حساب</button>
        </div>
      </aside>

      <div className="admin-main">
        <header className="admin-topbar">
          <button className="admin-mobile-menu" onClick={() => setMobileMenuOpen((open) => !open)} aria-label="باز کردن فهرست پنل"><Icon name="menu" /></button>
          <div className="admin-breadcrumb"><span>سازنده</span><Icon name="chevron" size={15} /><strong>{activeTab.label}</strong></div>
          <div className="admin-top-actions">
            <span className="admin-online"><i /> ذخیره‌سازی خودکار</span>
            <button className="button button-outline button-small" onClick={onViewSite}><Icon name="eye" size={16} /> نمایش سایت</button>
          </div>
        </header>

        <main className="admin-content">
          {tab === "overview" && (
            <>
              <div className="admin-page-heading">
                <div><p className="admin-eyebrow">فضای سازنده</p><h1>سلام {user.name}، خوش برگشتی.</h1><p>از همین‌جا سایتت را ببین، ویرایش کن و با مخاطب‌ها در ارتباط باش.</p></div>
                <button className="button button-dark" onClick={onViewSite}><Icon name="eye" size={17} /> گشت‌وگذار در سایت</button>
              </div>
              <div className="overview-welcome">
                <div className="overview-orbit"><Icon name="spark" size={28} /></div>
                <div><span className="section-kicker">استودیوی تو، قوانین تو</span><h2>همه‌چیز برای انتشار آماده است.</h2><p>فایل بارگذاری کن، صفحه بساز، پیام بگذار یا ظاهر سایت را عوض کن. تغییرها همین‌جا نگه‌داری می‌شوند.</p></div>
              </div>
              <div className="overview-actions">
                <button onClick={() => changeTab("files")}><span className="overview-action-icon"><Icon name="upload" /></span><span><strong>افزودن فایل</strong><small>هر نوع فایل از سیستم</small></span><Icon name="arrow" size={17} /></button>
                <button onClick={() => changeTab("announcements")}><span className="overview-action-icon"><Icon name="megaphone" /></span><span><strong>انتشار پیام</strong><small>خبر تازه‌ات را اعلام کن</small></span><Icon name="arrow" size={17} /></button>
                <button onClick={() => changeTab("settings")}><span className="overview-action-icon"><Icon name="settings" /></span><span><strong>شخصی‌سازی سایت</strong><small>نام، بنر، ایمیل و لینک‌ها</small></span><Icon name="arrow" size={17} /></button>
              </div>
              <div className="overview-columns">
                <section className="overview-column">
                  <div className="admin-section-title"><div><span className="admin-eyebrow">آخرین فایل‌ها</span><h2>کتابخانه‌ی سایت</h2></div><button className="text-button" onClick={() => changeTab("files")}>مدیریت فایل‌ها <Icon name="arrow" size={14} /></button></div>
                  {data.files.length ? data.files.slice(0, 4).map((file) => <div className="overview-list-row" key={file.id}><FileMark file={file} /><span><strong>{file.title}</strong><small>{formatBytes(file.size)} · {formatDate(file.createdAt)}</small></span></div>) : <p className="muted-note">هنوز فایلی بارگذاری نشده است.</p>}
                </section>
                <section className="overview-column">
                  <div className="admin-section-title"><div><span className="admin-eyebrow">صندوق پیام‌ها</span><h2>پشتیبانی</h2></div><button className="text-button" onClick={() => changeTab("support")}>دیدن پیام‌ها <Icon name="arrow" size={14} /></button></div>
                  {data.tickets.length ? data.tickets.slice(0, 3).map((ticket) => <div className="overview-ticket" key={ticket.id}><span className={`ticket-dot ${ticket.status === "new" ? "is-new" : ""}`} /><span><strong>{ticket.name}</strong><small>{ticket.message.slice(0, 58)}{ticket.message.length > 58 ? "…" : ""}</small></span><time>{formatDate(ticket.createdAt)}</time></div>) : <p className="muted-note">پیام‌های مخاطب‌ها اینجا نمایش داده می‌شوند.</p>}
                </section>
              </div>
              <p className="local-notice"><Icon name="alert" size={16} /> این نمونه در مرورگر همین دستگاه ذخیره می‌شود؛ برای انتشار عمومی و امنیت واقعی، اتصال به سرور لازم است.</p>
            </>
          )}

          {tab === "files" && (
            <>
              <div className="admin-page-heading"><div><p className="admin-eyebrow">کتابخانه</p><h1>مدیریت فایل‌ها</h1><p>هر نوع فایل را مستقیم از دستگاهت بارگذاری و در یک بخش منتشر کن.</p></div><span className="heading-count">{new Intl.NumberFormat("fa-IR").format(data.files.length)} فایل</span></div>
              <form className="editor-panel upload-panel" onSubmit={submitFile}>
                <div className="editor-panel-heading"><span className="editor-icon"><Icon name="upload" size={20} /></span><div><h2>فایل تازه</h2><p>تصویر، سند، ویدیو، فایل فشرده یا هر نوع فایل دیگر.</p></div></div>
                <label className={`file-picker${pendingFile ? " file-picker-selected" : ""}`}>
                  <input type="file" onChange={(event) => setPendingFile(event.target.files?.[0] ?? null)} />
                  <span className="file-picker-icon"><Icon name={pendingFile ? "check" : "plus"} size={20} /></span>
                  <span><strong>{pendingFile ? pendingFile.name : "انتخاب فایل از دستگاه"}</strong><small>{pendingFile ? formatBytes(pendingFile.size) : "برای انتخاب، اینجا کلیک کن یا فایل را بکش و رها کن"}</small></span>
                  <span className="picker-browse">انتخاب فایل</span>
                </label>
                <div className="form-grid">
                  <label className="field"><span>عنوان نمایشی</span><input value={fileTitle} onChange={(event) => setFileTitle(event.target.value)} required placeholder="مثلاً قالب آماده ارائه" /></label>
                  <label className="field"><span>بخش سایت</span><select value={fileSectionId} onChange={(event) => setFileSectionId(event.target.value)}><option value="">بدون دسته‌بندی</option>{data.sections.map((section) => <option key={section.id} value={section.id}>{section.label}</option>)}</select></label>
                  <label className="field field-full"><span>توضیح کوتاه</span><textarea value={fileDescription} onChange={(event) => setFileDescription(event.target.value)} rows={2} placeholder="این فایل برای چه کاری مناسب است؟" /></label>
                </div>
                <div className="form-actions"><span className="form-hint"><Icon name="shield" size={15} /> محتوا از رایانه انتخاب می‌شود، نه از نشانی اینترنتی.</span><button className="button button-dark" type="submit" disabled={!pendingFile || !fileTitle.trim()}>بارگذاری و انتشار <Icon name="arrow" size={16} /></button></div>
              </form>
              <div className="admin-list-heading"><div><h2>فایل‌های منتشرشده</h2><p>فایل‌های حذف‌شده دیگر از سایت قابل دریافت نیستند.</p></div><label className="admin-search"><Icon name="search" size={17} /><input value={fileQuery} onChange={(event) => setFileQuery(event.target.value)} placeholder="جست‌وجوی فایل" /></label></div>
              <div className="admin-file-list">
                {filteredAdminFiles.length ? filteredAdminFiles.map((file) => (
                  <div className="admin-file-row" key={file.id}>
                    <FileMark file={file} /><div className="admin-file-copy"><strong>{file.title}</strong><span>{file.fileName} · {formatBytes(file.size)}</span></div>
                    <span className="admin-file-section">{data.sections.find((section) => section.id === file.sectionId)?.label ?? "بدون دسته"}</span>
                    <span className="admin-download-count"><Icon name="download" size={15} /> {new Intl.NumberFormat("fa-IR").format(file.downloads)}</span>
                    <button className="icon-button danger-hover" onClick={() => onDeleteFile(file)} aria-label={`حذف ${file.title}`}><Icon name="trash" size={17} /></button>
                  </div>
                )) : <div className="admin-empty-state"><Icon name="folder" size={23} /><p>{fileQuery ? "فایلی با این جست‌وجو پیدا نشد." : "هنوز فایلی منتشر نکرده‌ای. اولین فایل را از همین فرم اضافه کن."}</p></div>}
              </div>
            </>
          )}

          {tab === "announcements" && (
            <>
              <div className="admin-page-heading"><div><p className="admin-eyebrow">ارتباط با مخاطب</p><h1>پیام‌های سایت</h1><p>خبر تازه، انتشار ویدیو یا هر یادداشت کوتاهی را برای بازدیدکننده‌ها منتشر کن.</p></div></div>
              <form className="editor-panel post-editor" onSubmit={submitPost}>
                <div className="editor-panel-heading"><span className="editor-icon"><Icon name="megaphone" size={20} /></span><div><h2>نوشتن پیام تازه</h2><p>پیام منتشرشده در صفحه‌ی اصلی سایت نمایش داده می‌شود.</p></div></div>
                <label className="field"><span>عنوان پیام</span><input value={postTitle} onChange={(event) => setPostTitle(event.target.value)} required placeholder="مثلاً ویدیوی جدید در یوتیوب منتشر شد" /></label>
                <label className="field"><span>متن پیام</span><textarea value={postBody} onChange={(event) => setPostBody(event.target.value)} rows={4} required placeholder="جزئیات خبر را برای مخاطب‌ها بنویس..." /></label>
                <div className="form-actions"><span className="form-hint">پیام‌ها تا وقتی حذفشان نکنی روی سایت می‌مانند.</span><button className="button button-dark" type="submit" disabled={!postTitle.trim() || !postBody.trim()}>انتشار پیام <Icon name="arrow" size={16} /></button></div>
              </form>
              <div className="admin-list-heading"><div><h2>پیام‌های منتشرشده</h2><p>{new Intl.NumberFormat("fa-IR").format(data.posts.length)} پیام در سایت</p></div></div>
              <div className="posts-admin-list">
                {data.posts.length ? data.posts.map((post) => <article className="post-admin-row" key={post.id}><span className="post-admin-date">{formatDate(post.createdAt)}</span><div><h3>{post.title}</h3><p>{post.body}</p></div><button className="icon-button danger-hover" onClick={() => onDeletePost(post)} aria-label={`حذف پیام ${post.title}`}><Icon name="trash" size={17} /></button></article>) : <div className="admin-empty-state"><Icon name="megaphone" size={23} /><p>هنوز پیامی منتشر نشده است.</p></div>}
              </div>
            </>
          )}

          {tab === "sections" && (
            <>
              <div className="admin-page-heading"><div><p className="admin-eyebrow">ساختار سایت</p><h1>بخش‌های سایت</h1><p>دسته‌بندی تازه بساز یا بخش‌های قبلی را حذف کن.</p></div></div>
              <form className="section-create-form" onSubmit={submitSection}>
                <span className="editor-icon"><Icon name="plus" size={20} /></span>
                <label className="field"><span>نام بخش تازه</span><input value={sectionName} onChange={(event) => setSectionName(event.target.value)} placeholder="مثلاً پروژه‌های ویدیویی" required /></label>
                <button className="button button-dark" type="submit"><Icon name="plus" size={16} /> ساخت بخش</button>
              </form>
              <div className="admin-list-heading"><div><h2>بخش‌های فعال</h2><p>با حذف بخش، فایل‌هایش به اولین بخش باقی‌مانده منتقل می‌شوند.</p></div></div>
              <div className="section-admin-list">
                {data.sections.length ? data.sections.map((section) => <div className="section-admin-row" key={section.id}><span className="section-admin-symbol"><Icon name="layers" size={19} /></span><div><strong>{section.label}</strong><small>{new Intl.NumberFormat("fa-IR").format(data.files.filter((file) => file.sectionId === section.id).length)} فایل</small></div><button className="icon-button danger-hover" onClick={() => onDeleteSection(section)} aria-label={`حذف بخش ${section.label}`}><Icon name="trash" size={17} /></button></div>) : <div className="admin-empty-state"><Icon name="layers" size={23} /><p>بخشی ساخته نشده؛ می‌توانی بخش اول را بسازی.</p></div>}
              </div>
            </>
          )}

          {tab === "support" && (
            <>
              <div className="admin-page-heading"><div><p className="admin-eyebrow">صندوق ورودی</p><h1>پیام‌های پشتیبانی</h1><p>پیام‌ها در همین پنل نگه‌داری می‌شوند؛ پاسخ تو در حساب مخاطب نمایش داده می‌شود.</p></div><span className="heading-count">{new Intl.NumberFormat("fa-IR").format(data.tickets.filter((ticket) => ticket.status === "new").length)} پاسخ‌نداده</span></div>
              <div className="ticket-list">
                {data.tickets.length ? [...data.tickets].reverse().map((ticket) => <article className="ticket-admin-row" key={ticket.id}>
                  <div className="ticket-admin-meta"><span className={`ticket-state ${ticket.status === "new" ? "ticket-state-new" : ""}`}><i />{ticket.status === "new" ? "تازه" : "پاسخ داده‌شده"}</span><time>{formatDate(ticket.createdAt)}</time></div>
                  <div className="ticket-admin-head"><div><h2>{ticket.name}</h2><a href={`mailto:${ticket.email}`}>{ticket.email} <Icon name="external" size={13} /></a></div><span className="ticket-initial">{ticket.name.slice(0, 1)}</span></div>
                  <p className="ticket-message">{ticket.message}</p>
                  {ticket.replies.map((reply, index) => <div className="ticket-reply" key={`${ticket.id}-reply-${index}`}><strong>پاسخ {reply.by}</strong><p>{reply.body}</p><time>{formatDate(reply.at)}</time></div>)}
                  <form className="ticket-reply-form" onSubmit={(event) => { event.preventDefault(); const text = replyDrafts[ticket.id]?.trim(); if (text) { onReply(ticket.id, text); setReplyDrafts((drafts) => ({ ...drafts, [ticket.id]: "" })); } }}>
                    <input value={replyDrafts[ticket.id] ?? ""} onChange={(event) => setReplyDrafts((drafts) => ({ ...drafts, [ticket.id]: event.target.value }))} placeholder="پاسخ برای مخاطب بنویس..." aria-label={`پاسخ به ${ticket.name}`} />
                    <button type="submit" className="button button-dark button-small" disabled={!replyDrafts[ticket.id]?.trim()}><Icon name="send" size={15} /> ارسال پاسخ</button>
                  </form>
                </article>) : <div className="admin-empty-state"><Icon name="message" size={23} /><p>هنوز پیامی از مخاطب‌ها دریافت نشده است.</p></div>}
              </div>
            </>
          )}

          {tab === "users" && (
            <>
              <div className="admin-page-heading"><div><p className="admin-eyebrow">دسترسی‌ها</p><h1>کاربران و مدیرها</h1><p>کاربرها بعد از ساخت حساب اینجا دیده می‌شوند. فقط مالک می‌تواند نقش مدیر بدهد.</p></div><span className="heading-count">{new Intl.NumberFormat("fa-IR").format(data.users.length)} حساب</span></div>
              {user.role !== "owner" && <div className="inline-warning"><Icon name="shield" size={17} /> تغییر نقش کاربران فقط در اختیار مالک سایت است.</div>}
              <div className="users-admin-list">
                {data.users.length ? data.users.map((account) => <div className="user-admin-row" key={account.id}>
                  <span className={`user-admin-avatar ${account.role === "owner" ? "owner-avatar" : ""}`}>{account.name.slice(0, 1)}</span>
                  <div className="user-admin-copy"><strong>{account.name}{account.id === user.id ? " (شما)" : ""}</strong><span>{account.email}</span></div>
                  <span className={`role-badge role-${account.role}`}><Icon name={account.role === "owner" ? "shield" : "user"} size={14} /> {roleLabel(account.role)}</span>
                  <span className="user-created">عضویت {formatDate(account.createdAt)}</span>
                  {user.role === "owner" && account.role !== "owner" && <button className={`role-action ${account.role === "admin" ? "role-remove" : ""}`} onClick={() => onSetRole(account.id, account.role === "admin" ? "member" : "admin")}><Icon name={account.role === "admin" ? "close" : "plus"} size={15} /> {account.role === "admin" ? "حذف مدیریت" : "تبدیل به مدیر"}</button>}
                </div>) : <div className="admin-empty-state"><Icon name="users" size={23} /><p>کاربری ثبت‌نام نکرده است.</p></div>}
              </div>
              <p className="local-notice"><Icon name="alert" size={16} /> ثبت‌نام و نقش‌ها در این نمونه روی همین دستگاه ذخیره می‌شوند و برای کاربران دستگاه‌های دیگر مشترک نیستند.</p>
            </>
          )}

          {tab === "settings" && (
            <>
              <div className="admin-page-heading"><div><p className="admin-eyebrow">شخصی‌سازی</p><h1>ظاهر و تنظیمات</h1><p>نام، شعار، راه‌های ارتباطی و بنر سایت را از همین‌جا تغییر بده.</p></div></div>
              <form className="settings-form" onSubmit={saveSettings}>
                <section className="settings-section">
                  <div className="settings-section-heading"><span className="editor-icon"><Icon name="spark" size={20} /></span><div><h2>هویت سایت</h2><p>تغییرات را ذخیره کن تا در سایت نمایش داده شوند.</p></div></div>
                  <div className="form-grid">
                    <label className="field"><span>نام سایت</span><input value={settingsDraft.siteName} onChange={(event) => setSettingsDraft((draft) => ({ ...draft, siteName: event.target.value }))} required /></label>
                    <label className="field"><span>شعار سایت</span><input value={settingsDraft.slogan} onChange={(event) => setSettingsDraft((draft) => ({ ...draft, slogan: event.target.value }))} /></label>
                    <label className="field"><span>ایمیل نمایش‌داده‌شده به مخاطب</span><input type="email" value={settingsDraft.contactEmail} onChange={(event) => setSettingsDraft((draft) => ({ ...draft, contactEmail: event.target.value }))} required /></label>
                    <label className="field"><span>لینک کانال یوتیوب یا ویدیو</span><input dir="ltr" value={settingsDraft.channelUrl} onChange={(event) => setSettingsDraft((draft) => ({ ...draft, channelUrl: event.target.value }))} placeholder="youtube.com/@yourchannel" /></label>
                    {user.role === "owner" && <label className="field"><span>ایمیل ورود مالک</span><input type="email" value={settingsDraft.ownerEmail} onChange={(event) => setSettingsDraft((draft) => ({ ...draft, ownerEmail: event.target.value }))} required /><small>با ذخیره، ایمیل ورود مالک هم به این نشانی تغییر می‌کند.</small></label>}
                  </div>
                  <div className="accent-field"><span className="field-label">رنگ تأکیدی</span><div className="accent-options">
                    {(["sage", "copper", "blue"] as Accent[]).map((accent) => <button type="button" key={accent} className={`accent-option accent-${accent}${settingsDraft.accent === accent ? " selected" : ""}`} onClick={() => setSettingsDraft((draft) => ({ ...draft, accent }))} aria-label={accent === "sage" ? "سبز زیتونی" : accent === "copper" ? "مسی" : "آبی"}><span />{accent === "sage" ? "زیتونی" : accent === "copper" ? "مسی" : "آبی"}{settingsDraft.accent === accent && <Icon name="check" size={15} />}</button>)}
                  </div></div>
                  <div className="settings-save-row"><span><Icon name="check" size={15} /> پیش‌نمایش سایت بعد از ذخیره به‌روز می‌شود.</span><button type="submit" className="button button-dark">ذخیره تنظیمات <Icon name="arrow" size={16} /></button></div>
                </section>
              </form>

              <section className="settings-section banner-settings">
                <div className="settings-section-heading"><span className="editor-icon"><Icon name="image" size={20} /></span><div><h2>بنر صفحه‌ی اصلی</h2><p>یک تصویر را از دستگاهت انتخاب کن؛ نیازی به لینک عکس نیست.</p></div></div>
                <div className="banner-preview" style={{ backgroundImage: `linear-gradient(90deg, rgba(20, 31, 25, .28), rgba(20, 31, 25, .65)), url("${bannerPreviewUrl || "/images/creative-studio.jpg"}")` }}>
                  <span>{data.settings.bannerAssetId ? "بنر بارگذاری‌شده" : "تصویر پیش‌فرض استودیو"}</span>
                </div>
                <label className="button button-outline banner-upload"><Icon name="upload" size={16} /> انتخاب تصویر از دستگاه<input type="file" accept="image/*" onChange={async (event) => { const file = event.target.files?.[0]; if (file) { setBannerMessage("در حال ذخیره تصویر…"); const saved = await onUploadBanner(file); setBannerMessage(saved ? "بنر جدید ذخیره شد." : "بارگذاری تصویر انجام نشد."); event.target.value = ""; } }} /></label>
                {bannerMessage && <p className="settings-feedback">{bannerMessage}</p>}
              </section>

              <section className="settings-section socials-settings">
                <div className="settings-section-heading"><span className="editor-icon"><Icon name="link" size={20} /></span><div><h2>شبکه‌های اجتماعی</h2><p>هر شبکه‌ای داری با نام و لینک دلخواه اضافه کن.</p></div></div>
                <div className="social-admin-list">
                  {settingsDraft.socials.map((social) => <div className="social-admin-row" key={social.id}><span className="social-admin-icon"><Icon name="external" size={17} /></span><div><strong>{social.label}</strong><span dir="ltr">{social.url}</span></div><button type="button" className="icon-button danger-hover" onClick={() => setSettingsDraft((draft) => ({ ...draft, socials: draft.socials.filter((item) => item.id !== social.id) }))} aria-label={`حذف ${social.label}`}><Icon name="trash" size={16} /></button></div>)}
                  {!settingsDraft.socials.length && <p className="muted-note">هنوز لینکی اضافه نشده است.</p>}
                </div>
                <form className="social-add-form" onSubmit={addSocial}>
                  <label className="field"><span>نام شبکه</span><input value={socialLabel} onChange={(event) => setSocialLabel(event.target.value)} placeholder="مثلاً اینستاگرام" required /></label>
                  <label className="field"><span>لینک پروفایل</span><input dir="ltr" value={socialUrl} onChange={(event) => setSocialUrl(event.target.value)} placeholder="instagram.com/username" required /></label>
                  <button className="button button-outline" type="submit"><Icon name="plus" size={16} /> افزودن لینک</button>
                </form>
                <p className="social-save-hint">برای نمایش لینک‌های اضافه‌شده در سایت، «ذخیره تنظیمات» را بزن.</p>
              </section>

              <section className="settings-section security-settings">
                <div className="settings-section-heading"><span className="editor-icon"><Icon name="key" size={20} /></span><div><h2>تغییر رمز ورود</h2><p>رمز حساب فعلی را با رمز تازه جایگزین کن.</p></div></div>
                <form className="password-change-form" onSubmit={submitPassword}>
                  <label className="field"><span>رمز فعلی</span><input type="password" autoComplete="current-password" value={currentPassword} onChange={(event) => setCurrentPassword(event.target.value)} required /></label>
                  <label className="field"><span>رمز تازه</span><input type="password" autoComplete="new-password" minLength={8} value={nextPassword} onChange={(event) => setNextPassword(event.target.value)} required /><small>حداقل ۸ نویسه.</small></label>
                  <button className="button button-outline" type="submit"><Icon name="lock" size={16} /> تغییر رمز</button>
                </form>
                {securityMessage && <p className="settings-feedback">{securityMessage}</p>}
                <div className="security-warning"><Icon name="alert" size={18} /><p><strong>مهم:</strong> رمزها در این نسخه با هش رمزنگاری‌شده نگه‌داری می‌شوند، اما چون برنامه سرور و پایگاه‌داده‌ی واقعی ندارد، این پنل برای انتشار عمومی امن محسوب نمی‌شود. برای امنیت واقعی باید احراز هویت و فایل‌ها به سرور منتقل شوند.</p></div>
              </section>
            </>
          )}
        </main>
      </div>
    </div>
  );
}

interface AuthDialogProps {
  user: UserRecord | null;
  data: SiteData;
  onClose: () => void;
  onLogin: (email: string, password: string) => Promise<AuthResult>;
  onRegister: (name: string, email: string, password: string) => Promise<AuthResult>;
  onAuthenticated: (user: UserRecord) => void;
  onLogout: () => void;
  onDownload: (file: FileRecord) => void;
}

function AuthDialog({ user, data, onClose, onLogin, onRegister, onAuthenticated, onLogout, onDownload }: AuthDialogProps) {
  const [mode, setMode] = useState<"login" | "register">("login");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  const handleSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setError("");
    setBusy(true);
    const result = mode === "login" ? await onLogin(email, password) : await onRegister(name, email, password);
    setBusy(false);
    if (!result.ok || !result.user) {
      setError(result.message);
      return;
    }
    onAuthenticated(result.user);
    onClose();
  };

  const history = user ? [...user.downloads].reverse().slice(0, 6) : [];
  const userTickets = user ? data.tickets.filter((ticket) => ticket.userId === user.id || ticket.email === user.email).slice().reverse() : [];

  return (
    <div className="modal-backdrop" onMouseDown={(event) => { if (event.target === event.currentTarget) onClose(); }}>
      <section className="modal auth-modal" role="dialog" aria-modal="true" aria-labelledby="auth-title">
        <button className="modal-close" onClick={onClose} aria-label="بستن"><Icon name="close" /></button>
        {user ? (
          <>
            <div className="modal-mark"><Icon name="user" size={22} /></div>
            <p className="modal-eyebrow">حساب کاربری</p>
            <h2 id="auth-title">سلام، {user.name}</h2>
            <p className="modal-intro">{user.email} <span className={`role-badge role-${user.role}`}>{roleLabel(user.role)}</span></p>
            <div className="account-history">
              <div className="account-section-title"><h3>تاریخچه‌ی دریافت‌ها</h3><span>{new Intl.NumberFormat("fa-IR").format(user.downloads.length)}</span></div>
              {history.length ? history.map((entry, index) => {
                const file = data.files.find((item) => item.id === entry.fileId);
                return <div className="history-row" key={`${entry.fileId}-${entry.at}-${index}`}><Icon name="download" size={16} /><span><strong>{file?.title ?? "فایل حذف‌شده"}</strong><small>{formatDate(entry.at)}</small></span>{file && <button className="text-button" onClick={() => onDownload(file)}>دریافت دوباره</button>}</div>;
              }) : <p className="muted-note">هنوز فایلی دریافت نکرده‌ای.</p>}
            </div>
            {userTickets.length > 0 && <div className="account-history account-support-history"><div className="account-section-title"><h3>پیام‌های پشتیبانی</h3><span>{new Intl.NumberFormat("fa-IR").format(userTickets.length)}</span></div>{userTickets.slice(0, 3).map((ticket) => <div className="account-ticket" key={ticket.id}><strong>{ticket.message}</strong>{ticket.replies.map((reply, index) => <p key={`${ticket.id}-${index}`}><b>پاسخ:</b> {reply.body}</p>)}</div>)}</div>}
            <div className="account-modal-actions"><button className="button button-outline" onClick={() => { onLogout(); setError(""); }}>ورود با حساب دیگر</button><button className="button button-dark" onClick={onLogout}><Icon name="logout" size={16} /> خروج</button></div>
          </>
        ) : (
          <>
            <div className="modal-mark"><Icon name={mode === "login" ? "lock" : "user"} size={22} /></div>
            <p className="modal-eyebrow">همراه استودیو</p>
            <h2 id="auth-title">{mode === "login" ? "خوش برگشتی" : "ساخت حساب کاربری"}</h2>
            <p className="modal-intro">با ایمیلت وارد شو تا تاریخچه‌ی دریافت فایل‌هایت بماند.</p>
            <form className="modal-form" onSubmit={handleSubmit}>
              {mode === "register" && <label className="field"><span>نام نمایشی</span><input value={name} onChange={(event) => setName(event.target.value)} autoComplete="name" required placeholder="نام شما" /></label>}
              <label className="field"><span>ایمیل</span><input type="email" value={email} onChange={(event) => setEmail(event.target.value)} autoComplete="username" required placeholder="name@example.com" /></label>
              <label className="field"><span>رمز عبور</span><input type="password" value={password} onChange={(event) => setPassword(event.target.value)} autoComplete={mode === "login" ? "current-password" : "new-password"} minLength={mode === "register" ? 8 : undefined} required placeholder={mode === "register" ? "حداقل ۸ نویسه" : "رمز عبور"} /></label>
              {error && <p className="form-error"><Icon name="alert" size={15} />{error}</p>}
              <button className="button button-dark modal-submit" type="submit" disabled={busy}>{busy ? "در حال بررسی…" : mode === "login" ? "ورود به حساب" : "ساخت حساب"}<Icon name="arrow" size={16} /></button>
            </form>
            <p className="auth-switch">{mode === "login" ? "حساب نداری؟" : "قبلاً حساب ساخته‌ای؟"}<button onClick={() => { setMode(mode === "login" ? "register" : "login"); setError(""); }}>{mode === "login" ? "ثبت‌نام کن" : "وارد شو"}</button></p>
            <p className="modal-footnote"><Icon name="shield" size={14} /> این نسخه آزمایشی، اطلاعات را فقط در همین مرورگر ذخیره می‌کند.</p>
          </>
        )}
      </section>
    </div>
  );
}

interface SupportDialogProps {
  user: UserRecord | null;
  contactEmail: string;
  onClose: () => void;
  onSend: (draft: SupportDraft) => void;
}

function SupportDialog({ user, contactEmail, onClose, onSend }: SupportDialogProps) {
  const [name, setName] = useState(user?.name ?? "");
  const [email, setEmail] = useState(user?.email ?? "");
  const [message, setMessage] = useState("");
  const [sent, setSent] = useState(false);

  const submit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    onSend({ name: name.trim(), email: email.trim(), message: message.trim(), userId: user?.id });
    setSent(true);
  };

  return (
    <div className="modal-backdrop" onMouseDown={(event) => { if (event.target === event.currentTarget) onClose(); }}>
      <section className="modal support-modal" role="dialog" aria-modal="true" aria-labelledby="support-title">
        <button className="modal-close" onClick={onClose} aria-label="بستن"><Icon name="close" /></button>
        {sent ? (
          <div className="success-state"><span className="success-mark"><Icon name="check" size={24} /></span><p className="modal-eyebrow">پیام ثبت شد</p><h2 id="support-title">ممنون که نوشتی.</h2><p>پیامت در صندوق پشتیبانی ثبت شد. اگر وارد حساب شده باشی، پاسخ را در بخش حساب کاربری می‌بینی.</p><button className="button button-dark" onClick={onClose}>بستن</button></div>
        ) : (
          <>
            <div className="modal-mark"><Icon name="message" size={22} /></div>
            <p className="modal-eyebrow">پشتیبانی استودیو</p>
            <h2 id="support-title">چطور می‌توانیم کمک کنیم؟</h2>
            <p className="modal-intro">پیامت را همین‌جا بفرست، لازم نیست برنامه‌ی ایمیل را باز کنی.</p>
            <form className="modal-form" onSubmit={submit}>
              <label className="field"><span>نام</span><input value={name} onChange={(event) => setName(event.target.value)} required autoComplete="name" /></label>
              <label className="field"><span>ایمیل برای پاسخ</span><input type="email" value={email} onChange={(event) => setEmail(event.target.value)} required autoComplete="email" /></label>
              <label className="field"><span>پیام</span><textarea value={message} onChange={(event) => setMessage(event.target.value)} rows={4} minLength={5} required placeholder="متنت را اینجا بنویس…" /></label>
              <button className="button button-dark modal-submit" type="submit" disabled={message.trim().length < 5}>ارسال پیام <Icon name="send" size={16} /></button>
            </form>
            <a className="modal-direct-email" href={`mailto:${contactEmail}`}><Icon name="mail" size={15} /> یا ایمیل بزن به {contactEmail}</a>
          </>
        )}
      </section>
    </div>
  );
}

function Toast({ message, kind }: { message: string; kind: "success" | "error" }) {
  return <div className={`toast toast-${kind}`} role="status"><Icon name={kind === "success" ? "check" : "alert"} size={17} />{message}</div>;
}

export default function App() {
  const [data, setData] = useState<SiteData>(EMPTY_DATA);
  const [ready, setReady] = useState(false);
  const [currentUserId, setCurrentUserId] = useState("");
  const [view, setView] = useState<View>("site");
  const [selectedSection, setSelectedSection] = useState("all");
  const [authOpen, setAuthOpen] = useState(false);
  const [supportOpen, setSupportOpen] = useState(false);
  const [adminEntryPending, setAdminEntryPending] = useState(false);
  const [toast, setToast] = useState<{ message: string; kind: "success" | "error" } | null>(null);
  const currentUser = data.users.find((user) => user.id === currentUserId) ?? null;

  const notify = (message: string, kind: "success" | "error" = "success") => {
    setToast({ message, kind });
    window.setTimeout(() => setToast(null), 3600);
  };

  useEffect(() => {
    let active = true;
    const initialize = async () => {
      try {
        const ownerPassword = await derivePassword(DEFAULT_OWNER_PASSWORD);
        const owner: UserRecord = {
          id: "owner-main",
          name: "الیاس",
          email: DEFAULT_SETTINGS.ownerEmail,
          role: "owner",
          passwordSalt: ownerPassword.salt,
          passwordHash: ownerPassword.hash,
          downloads: [],
          createdAt: new Date().toISOString(),
        };
        const saved = window.localStorage.getItem(DATA_KEY);
        let nextData: SiteData;
        if (saved) {
          try {
            const parsed = JSON.parse(saved) as Partial<SiteData>;
            const settings = { ...DEFAULT_SETTINGS, ...(parsed.settings ?? {}) } as SiteSettings;
            const users = Array.isArray(parsed.users) ? parsed.users : [];
            const existingOwner = users.find((account) => account.role === "owner");
            settings.ownerEmail = existingOwner?.email ?? settings.ownerEmail ?? owner.email;
            nextData = {
              settings,
              sections: Array.isArray(parsed.sections) ? parsed.sections : DEFAULT_SECTIONS,
              files: Array.isArray(parsed.files) ? parsed.files : [],
              posts: Array.isArray(parsed.posts) ? parsed.posts : [],
              users: existingOwner ? users as UserRecord[] : [...users as UserRecord[], { ...owner, email: settings.ownerEmail }],
              tickets: Array.isArray(parsed.tickets) ? parsed.tickets : [],
            };
            nextData.settings.socials = Array.isArray(settings.socials) ? settings.socials : [];
          } catch {
            nextData = { ...EMPTY_DATA, settings: { ...DEFAULT_SETTINGS }, sections: [...DEFAULT_SECTIONS], users: [owner] };
          }
        } else {
          nextData = { ...EMPTY_DATA, settings: { ...DEFAULT_SETTINGS }, sections: [...DEFAULT_SECTIONS], users: [owner], files: [] };
          try {
            const guideText = "راهنمای استفاده از سایت\n\nبرای دریافت فایل‌ها، از صفحه اصلی یک دسته را انتخاب و روی دکمه دریافت فایل بزنید.\nبرای مدیریت سایت، وارد پنل سازنده شوید.\n\nاین فایل نمونه را می‌توانید از پنل سازنده حذف کنید.";
            const assetId = await saveAsset(new Blob([guideText], { type: "text/plain;charset=utf-8" }), "راهنمای-شروع.txt");
            nextData.files = [{
              id: makeId("file"),
              title: "راهنمای شروع کار",
              fileName: "راهنمای-شروع.txt",
              description: "یک فایل نمونه برای آشنایی با دریافت فایل‌ها و پنل سایت.",
              sectionId: "resources",
              assetId,
              mime: "text/plain",
              size: new Blob([guideText]).size,
              createdAt: new Date().toISOString(),
              downloads: 0,
            }];
          } catch {
            // The site remains usable if this browser blocks local file storage.
          }
        }

        if (!active) return;
        setData(nextData);
        const savedSession = window.localStorage.getItem(SESSION_KEY);
        setCurrentUserId(nextData.users.some((user) => user.id === savedSession) ? savedSession ?? "" : "");
        setReady(true);
      } catch {
        if (!active) return;
        setData({ ...EMPTY_DATA, settings: { ...DEFAULT_SETTINGS }, sections: [...DEFAULT_SECTIONS] });
        setReady(true);
        notify("راه‌اندازی فضای محلی انجام نشد؛ برخی امکانات ذخیره‌سازی محدود است.", "error");
      }
    };
    void initialize();
    return () => { active = false; };
  }, []);

  useEffect(() => {
    if (!ready) return;
    try {
      window.localStorage.setItem(DATA_KEY, JSON.stringify(data));
    } catch {
      notify("فضای ذخیره‌سازی مرورگر پر شده است؛ فایل‌های بزرگ‌تری اضافه نکن.", "error");
    }
  }, [data, ready]);

  useEffect(() => {
    document.documentElement.lang = "fa";
    document.documentElement.dir = "rtl";
    document.title = data.settings.siteName || "استودیو الیاس";
  }, [data.settings.siteName]);

  useEffect(() => {
    if (selectedSection !== "all" && !data.sections.some((section) => section.id === selectedSection)) {
      setSelectedSection("all");
    }
  }, [data.sections, selectedSection]);

  const login = async (email: string, password: string): Promise<AuthResult> => {
    const account = data.users.find((user) => user.email.toLocaleLowerCase() === email.trim().toLocaleLowerCase());
    if (!account) return { ok: false, message: "حسابی با این ایمیل پیدا نشد." };
    try {
      const candidate = await derivePassword(password, account.passwordSalt);
      if (candidate.hash !== account.passwordHash) return { ok: false, message: "ایمیل یا رمز عبور درست نیست." };
      return { ok: true, message: "ورود انجام شد.", user: account };
    } catch {
      return { ok: false, message: "بررسی رمز عبور انجام نشد؛ مرورگر را به‌روز کن." };
    }
  };

  const register = async (name: string, email: string, password: string): Promise<AuthResult> => {
    const normalizedEmail = email.trim().toLocaleLowerCase();
    if (data.users.some((user) => user.email.toLocaleLowerCase() === normalizedEmail)) {
      return { ok: false, message: "با این ایمیل قبلاً حساب ساخته شده است." };
    }
    if (password.length < 8) return { ok: false, message: "رمز عبور باید دست‌کم ۸ نویسه داشته باشد." };
    try {
      const credential = await derivePassword(password);
      const account: UserRecord = {
        id: makeId("user"),
        name: name.trim(),
        email: normalizedEmail,
        role: "member",
        passwordSalt: credential.salt,
        passwordHash: credential.hash,
        downloads: [],
        createdAt: new Date().toISOString(),
      };
      setData((previous) => ({ ...previous, users: [...previous.users, account] }));
      return { ok: true, message: "حساب ساخته شد.", user: account };
    } catch {
      return { ok: false, message: "ساخت حساب ممکن نشد؛ دوباره تلاش کن." };
    }
  };

  const authenticate = (user: UserRecord) => {
    window.localStorage.setItem(SESSION_KEY, user.id);
    setCurrentUserId(user.id);
    const deniedCreatorAccess = adminEntryPending && user.role === "member";
    if (adminEntryPending) {
      setAdminEntryPending(false);
      if (user.role === "owner" || user.role === "admin") {
        setView("admin");
      }
    }
    notify(deniedCreatorAccess ? "این حساب دسترسی پنل سازنده را ندارد." : "با موفقیت وارد شدی.", deniedCreatorAccess ? "error" : "success");
  };

  const logout = () => {
    window.localStorage.removeItem(SESSION_KEY);
    setCurrentUserId("");
    setView("site");
    setAdminEntryPending(false);
    notify("از حساب خارج شدی.");
  };

  const openAdmin = () => {
    if (currentUser?.role === "owner" || currentUser?.role === "admin") {
      setView("admin");
      return;
    }
    setAdminEntryPending(true);
    setAuthOpen(true);
  };

  const downloadFile = async (file: FileRecord) => {
    try {
      const asset = await readAsset(file.assetId);
      if (!asset) {
        notify("فایل در فضای مرورگر پیدا نشد؛ دوباره بارگذاری‌اش کن.", "error");
        return;
      }
      const url = URL.createObjectURL(asset.blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = file.fileName;
      document.body.appendChild(link);
      link.click();
      link.remove();
      window.setTimeout(() => URL.revokeObjectURL(url), 1500);
      setData((previous) => ({
        ...previous,
        files: previous.files.map((item) => item.id === file.id ? { ...item, downloads: item.downloads + 1 } : item),
        users: currentUserId ? previous.users.map((user) => user.id === currentUserId ? { ...user, downloads: [...user.downloads, { fileId: file.id, at: new Date().toISOString() }] } : user) : previous.users,
      }));
      notify("دریافت فایل آغاز شد.");
    } catch {
      notify("دریافت فایل انجام نشد؛ دوباره تلاش کن.", "error");
    }
  };

  const createFile = async (file: File, title: string, description: string, sectionId: string) => {
    try {
      const assetId = await saveAsset(file, file.name);
      const record: FileRecord = {
        id: makeId("file"),
        title,
        fileName: file.name,
        description,
        sectionId,
        assetId,
        mime: file.type || "application/octet-stream",
        size: file.size,
        createdAt: new Date().toISOString(),
        downloads: 0,
      };
      setData((previous) => ({ ...previous, files: [record, ...previous.files] }));
      notify("فایل با موفقیت در سایت منتشر شد.");
      return true;
    } catch {
      notify("ذخیره فایل ناموفق بود. فضای ذخیره‌سازی مرورگر را بررسی کن.", "error");
      return false;
    }
  };

  const deleteFile = (file: FileRecord) => {
    if (!window.confirm(`فایل «${file.title}» حذف شود؟`)) return;
    setData((previous) => ({ ...previous, files: previous.files.filter((item) => item.id !== file.id) }));
    void removeAsset(file.assetId).catch(() => undefined);
    notify("فایل حذف شد.");
  };

  const uploadBanner = async (file: File) => {
    if (!file.type.startsWith("image/")) {
      notify("برای بنر، یک فایل تصویری انتخاب کن.", "error");
      return false;
    }
    try {
      const assetId = await saveAsset(file, file.name);
      const oldAsset = data.settings.bannerAssetId;
      setData((previous) => ({ ...previous, settings: { ...previous.settings, bannerAssetId: assetId } }));
      if (oldAsset) void removeAsset(oldAsset).catch(() => undefined);
      notify("بنر تازه روی سایت قرار گرفت.");
      return true;
    } catch {
      notify("بارگذاری بنر انجام نشد.", "error");
      return false;
    }
  };

  const saveSettings = (settings: SiteSettings) => {
    if (currentUser?.role === "owner" && data.users.some((account) => account.role !== "owner" && account.email.toLocaleLowerCase() === settings.ownerEmail.trim().toLocaleLowerCase())) {
      notify("این ایمیل برای حساب دیگری استفاده شده است.", "error");
      return;
    }
    if (currentUser?.role !== "owner") settings.ownerEmail = data.settings.ownerEmail;
    const cleanSettings = { ...settings, socials: settings.socials.map((social) => ({ ...social, url: normalizeUrl(social.url) })) };
    setData((previous) => ({
      ...previous,
      settings: cleanSettings,
      users: previous.users.map((user) => user.role === "owner" ? { ...user, email: cleanSettings.ownerEmail } : user),
    }));
    notify("تنظیمات سایت ذخیره شد.");
  };

  const createPost = (title: string, body: string) => {
    const post: PostRecord = { id: makeId("post"), title, body, createdAt: new Date().toISOString() };
    setData((previous) => ({ ...previous, posts: [post, ...previous.posts] }));
    notify("پیام در صفحه‌ی اصلی منتشر شد.");
  };

  const deletePost = (post: PostRecord) => {
    if (!window.confirm(`پیام «${post.title}» حذف شود؟`)) return;
    setData((previous) => ({ ...previous, posts: previous.posts.filter((item) => item.id !== post.id) }));
    notify("پیام حذف شد.");
  };

  const createSection = (name: string) => {
    const label = name.trim();
    if (!label) return false;
    if (data.sections.some((section) => section.label.toLocaleLowerCase() === label.toLocaleLowerCase())) {
      notify("بخشی با این نام وجود دارد.", "error");
      return false;
    }
    setData((previous) => ({ ...previous, sections: [...previous.sections, { id: makeId("section"), label }] }));
    notify("بخش تازه ساخته شد.");
    return true;
  };

  const deleteSection = (section: Section) => {
    if (!window.confirm(`بخش «${section.label}» حذف شود؟ فایل‌های آن منتقل می‌شوند.`)) return;
    const remaining = data.sections.filter((item) => item.id !== section.id);
    const fallback = remaining[0]?.id ?? "";
    setData((previous) => ({
      ...previous,
      sections: remaining,
      files: previous.files.map((file) => file.sectionId === section.id ? { ...file, sectionId: fallback } : file),
    }));
    if (selectedSection === section.id) setSelectedSection("all");
    notify("بخش حذف شد و فایل‌هایش حفظ شدند.");
  };

  const sendSupport = (draft: SupportDraft) => {
    const ticket: SupportTicket = {
      id: makeId("ticket"),
      ...draft,
      createdAt: new Date().toISOString(),
      status: "new",
      replies: [],
    };
    setData((previous) => ({ ...previous, tickets: [...previous.tickets, ticket] }));
    notify("پیام به صندوق پشتیبانی فرستاده شد.");
  };

  const replyToTicket = (ticketId: string, body: string) => {
    const reply: TicketReply = { body, by: currentUser?.name ?? "سازنده", at: new Date().toISOString() };
    setData((previous) => ({
      ...previous,
      tickets: previous.tickets.map((ticket) => ticket.id === ticketId ? { ...ticket, status: "answered", replies: [...ticket.replies, reply] } : ticket),
    }));
    notify("پاسخ برای مخاطب ثبت شد.");
  };

  const setUserRole = (userId: string, role: Role) => {
    if (currentUser?.role !== "owner") {
      notify("فقط مالک می‌تواند نقش مدیر بدهد.", "error");
      return;
    }
    setData((previous) => ({ ...previous, users: previous.users.map((user) => user.id === userId && user.role !== "owner" ? { ...user, role } : user) }));
    notify(role === "admin" ? "کاربر به مدیر تبدیل شد." : "دسترسی مدیریت برداشته شد.");
  };

  const changePassword = async (current: string, next: string) => {
    if (!currentUser || next.length < 8) return false;
    try {
      const candidate = await derivePassword(current, currentUser.passwordSalt);
      if (candidate.hash !== currentUser.passwordHash) return false;
      const replacement = await derivePassword(next);
      setData((previous) => ({ ...previous, users: previous.users.map((user) => user.id === currentUser.id ? { ...user, passwordSalt: replacement.salt, passwordHash: replacement.hash } : user) }));
      notify("رمز عبور تغییر کرد.");
      return true;
    } catch {
      return false;
    }
  };

  if (!ready) {
    return <div className="loading-screen"><span className="loading-symbol"><Icon name="spark" size={25} /></span><p>فضای استودیو در حال آماده‌شدن است…</p></div>;
  }

  return (
    <div className={`app-shell theme-${data.settings.accent}`}>
      {view === "site" ? (
        <PublicSite
          data={data}
          user={currentUser}
          selectedSection={selectedSection}
          onSelectSection={setSelectedSection}
          onOpenAccount={() => setAuthOpen(true)}
          onOpenSupport={() => setSupportOpen(true)}
          onOpenAdmin={openAdmin}
          onDownload={(file) => void downloadFile(file)}
        />
      ) : currentUser && (currentUser.role === "owner" || currentUser.role === "admin") ? (
        <AdminPanel
          data={data}
          user={currentUser}
          onViewSite={() => setView("site")}
          onLogout={logout}
          onCreateFile={createFile}
          onDeleteFile={deleteFile}
          onCreatePost={createPost}
          onDeletePost={deletePost}
          onCreateSection={createSection}
          onDeleteSection={deleteSection}
          onReply={replyToTicket}
          onSetRole={setUserRole}
          onSaveSettings={saveSettings}
          onUploadBanner={uploadBanner}
          onChangePassword={changePassword}
        />
      ) : <PublicSite data={data} user={currentUser} selectedSection={selectedSection} onSelectSection={setSelectedSection} onOpenAccount={() => setAuthOpen(true)} onOpenSupport={() => setSupportOpen(true)} onOpenAdmin={openAdmin} onDownload={(file) => void downloadFile(file)} />}

      {authOpen && <AuthDialog user={currentUser} data={data} onClose={() => setAuthOpen(false)} onLogin={login} onRegister={register} onAuthenticated={authenticate} onLogout={logout} onDownload={(file) => void downloadFile(file)} />}
      {supportOpen && <SupportDialog user={currentUser} contactEmail={data.settings.contactEmail} onClose={() => setSupportOpen(false)} onSend={sendSupport} />}
      {toast && <Toast message={toast.message} kind={toast.kind} />}
    </div>
  );
}